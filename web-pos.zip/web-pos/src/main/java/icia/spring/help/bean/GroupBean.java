package icia.spring.help.bean;

import java.util.ArrayList;

import lombok.Data;

@Data
public class GroupBean {
	private String groupCode;
	private String groupName;
	private String groupCeo;
	private String groupPin;
	private String message;
	private ArrayList<StoreBean> storeInfoList;
	
	
}
