package icia.spring.help.bean;

import lombok.Data;

@Data
public class CategoriesBean {
	private String levCode;
	private String levName;
	
	
}
