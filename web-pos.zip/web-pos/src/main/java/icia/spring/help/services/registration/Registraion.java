package icia.spring.help.services.registration;

public interface Registraion {
	/* Registration Class
	 * - 대표자등록
	 * - 상점등록
	 * - 직원등록
	 * - 분류등록 
	 * */
		public void backController();
		
		/* 회원가입 첫 페이지 이동 */
		public void moveGroup();
		
		/* 그룹네임 중복 체크 >> 임시 저장 */
		public void groupNameDuplicateCheckCtl();
		
		/* 그룹네임 삭제 >> 임시 저장 */
		public void delGroupNameCtl();
		
		/* 회원가입 :: 그룹코드 생성 */
		public void regGroupCtl();
		
		/* 회원가입2 :: 매장코드 생성 */
		public void regStoreCtl();
		
		public void makeHTMLSelectBox();
		
		public void makeMessage();
		
		/* 회원가입4 :: 직원코드 생성 */
		public void regEmpCtl();
		
		/* 회원가입3 :: 분류코드 생성 */
		public void regCategoriesCtl();
		
		/* Convert to Boolean */
		public void convertToBoolean();
		
		/* Referer Page 추출 */
		public void getRefererPage();
		
	

}
