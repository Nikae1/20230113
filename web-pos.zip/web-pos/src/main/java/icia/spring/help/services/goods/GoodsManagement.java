package icia.spring.help.services.goods;

public interface GoodsManagement {

		
		public void backController();
		
		
		/* 상품테이블에 데이터를 입력하는 메소드 */
		public void  insGoodsCtl();
		
		
		public void getGoodsCtl();

		
		public void insCategoryCtl();
		
			
		public void getCategoryListCtl();
		
		
		public void updCategoryCtl();
			
			
		public void getMaxIdx();
		
		
		public void convertToboolean();
	
	
}
