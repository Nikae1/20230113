package icia.spring.help.mapper;

import icia.spring.help.bean.GroupBean;

public interface AuthMapperInterface {

	public int isGroupName(GroupBean group);
	
}
