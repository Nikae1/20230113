/**
 * 인증 전 사용할 자바스크립트
 */
const jsonData = '';

/* HttpRequest를 이용한 서버 요청
		clientData format : [['name', 'value'], ...]
 */
function serverCallByRequest(jobCode, methodType, clientData){
	const form = createForm("", jobCode, methodType);
	if(clientData != ''){
		for(let idx=0;idx<clientData.length;idx++){
			form.appendChild(createInputBox('hidden', clentData[idx][0], clentData[idx][1], ''));
		}
	}
	document.body.appendChild(form);
	form.submit();
}

function serverCallByXHRAjax(formData, jobCode, methodType, callBackFunc){
	const ajax =  new XMLHttpRequest();
	
	ajax.onreadystatechange = function(){
		if(ajax.readyState == 4 && ajax.status == 200){
			window[callBackFunc](JSON.parse(ajax.responseText));
		}
	};
	
	ajax.open(methodType, jobCode);

	//ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	//ajax.setRequestHeader("Content-Type", "application/json");

	ajax.send(formData);	
}

/* 

*/





function serverCallByFetchAjax(formData, jobCode, methodType, callBackFunc){
	fetch(jobCode, {
  	method: methodType,
  	/*
    headers: {
    	'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: new URLSearchParams(formData)
    */
    body:formData
  })
  	.then((response) => response.json())
  	.then((data) => window[callBackFunc](data));
  
}




function nextJoinStep(step){
	let formData = null;
	
	let groupInfo = [['groupName', ''],['groupCeo', ''],['groupPin', ''],
					 ['storeCode', ''],['storeName', ''],['storePhone', ''],
					 ['storeZip', ''],['storeAddr', ''],['storeAddrDetail', '']];
	switch(step){
		case 1:
			const gpName = document.getElementsByName('groupName')[0];
	
	//	console.log(groupName.value);
			if(lengthCheck(gpName.value)){
				formData = new FormData();
				
				formData.append(gpName.name, gpName.value);
				console.log(gpName.name, gpName.value);
				groupInfo[0][1] = gpName.value;
				
				console.log(groupInfo[0]);
				// append(name,[blob ,] [value | fileName]) set(name,[blob ,] [value | fileName]) --> overwrite
				//console.log(formData);
				//serverCallByXHRAjax(formData, 'GroupDupChk', 'post', 'moveJoinStep2');
				
			//	const gn = createInputBox("hidden", "groupName", gpName.value, "");
				
				serverCallByFetchAjax(formData, 'GroupDupChk', 'post', 'moveJoinStep2');   
				
			}else{
				messageController(true, '그룹명 입력 오류:사용할 그룹명을 문자로 시작하는 두 글자 이상으로 입력하세요');
			}		
			break;
			
		case 2:
		
		
		if(lengthCheck(document.getElementsByName('groupCeo')[0].value)){
			
	
		// const groupName = document.getElementsByName('groupName')[0];
		const groupCeo = document.getElementsByName('groupCeo')[0];
		const groupPin = document.getElementsByName('groupPin')[0];
		const storeCode = document.getElementsByName('storeCode')[0];
		const storeName = document.getElementsByName('storeName')[0];
		const storePhone = document.getElementsByName('storePhone')[0];
		const storeZip = document.getElementsByName('storeZip')[0];
		const storeAddr = document.getElementsByName('storeAddr')[0];
		const storeAddrDetail = document.getElementsByName('storeAddrDetail')[0];
	
		
			//	console.log(gpName.name, gpName.value);
				console.log(groupCeo.name, groupCeo.value);
				console.log(groupPin.name, groupPin.value);
				console.log(storeCode.name, storeCode.value);
				console.log(storeName.name, storeName.value);
				console.log(storePhone.name, storePhone.value);
				console.log(storeZip.name, storeZip.value);
				console.log(storeAddr.name, storeAddr.value);
				console.log(storeAddrDetail.name, storeAddrDetail.value);
				
			    formData.append(groupName.name, groupName.value);		
			    formData.append(groupCeo.name, groupCeo.value);		
			    formData.append(groupPin.name, groupPin.value);		
			    formData.append(storeCode.name, storeCode.value);		
			    formData.append(storeName.name, storeName.value);		
			    formData.append(storePhone.name, storePhone.value);		
			    formData.append(storeZip.name, storeZip.value);		
			    formData.append(storeAddr.name, storeAddr.value);		
			    formData.append(storeAddrDetail.name, storeAddrDetail.value);		
			   		
				
	//			console.log(JSON.groupName.name, JSON.groupName.value);				
			
//			for(idx=1; idx<=groupInfo; idx++){
//				 groupInfo[idx][1] = document.getElementsByName(groupInfo[idx])[0].value;
//				 formData.append(groupInfo[idx], groupInfo[idx][1]);
			
	//		if(step == 4){		
	//		}
			
			}
		//	console.log(formData);
			serverCallByFetchAjax(formData, 'MemberJoin', 'post', 'moveJoinStep2');   
		//		formData.append(groupCeo.name, groupCeo.value);
		//		formData.append(groupPin.name, groupPin.value);
			}
		break;
	
	
}

function moveJoinStep2(jsonData){
	console.log(jsonData);
	
	const box = document.getElementsByClassName('communicationBox single')[0];
	
	if(jsonData.message == null){
		itemStyleChange(1);
	}else{
		messageController(true, jsonData.message);
		box.children[0].children[0].value = "";
	}
}


let idx = 1;
function moveJoinStep3(jsonData){
	console.log(jsonData);
	
	const box = document.getElementsByClassName('communicationBox single')[0];
	
	if(jsonData.message == null){
		box.children[1].style.display = 'block';
		box.children[1].children[0].value = box.children[0].children[0].value;
		box.children[0].style.display = 'none';
		box.children[0].children[0].value = "";
		box.className = 'communicationBox tripple';	
		
		idx++;
		document.getElementsByClassName("btn double on")[0].setAttribute("OnClick", "nextJoinStep("+idx+")");
	}

	/*
	else if(jsonData.groupName !='' && jsonData.message == null){
		box.children[1].style.display = 'block';
		box.children[2].style.display = 'none';
		box.className = 'communicationBox tripple';	
	
		console.log(2);
	}else if(jsonData.groupCeo !='' && jsonData.groupPin !=''){
		box.children[2].style.display = 'block';
		box.children[3].style.display = 'none';
		box.className = 'communicationBox tripple';	
	
		console.log(3);	
	}
	*/
	else{
		messageController(true, jsonData.message);
		box.children[0].children[0].value = "";
	}
	
}

/* 같은 페이지내 CommunicationBox와 페이지 하단 Command Button의 속성을 
   동적으로 적용하기 위한 전역 변수화 */
let itemIdx=0;
let Idx = 1;
function itemStyleChange(idx){
	console.log(itemIdx);
	const currentIdx = itemIdx + idx;
	const box = document.getElementsByClassName('communicationBox')[0];
	box.children[currentIdx].style.display = 'block';
	box.children[itemIdx].style.display = 'none';
	console.log(currentIdx);
	if(currentIdx >= 1)	box.className = 'communicationBox tripple'
	else box.className = 'communicationBox single';
	
	if(currentIdx == 1 && currentIdx>itemIdx){
		if(currentIdx>itemIdx) {
			box.children[currentIdx].children[0].value = box.children[itemIdx].children[0].value;
			box.children[itemIdx].children[0].value = "";
		}
		
		const parent = document.getElementById("footer");
		parent.firstElementChild.className = "btn tripple on";
		parent.lastElementChild.className = "btn tripple on";
		Idx++;
		parent.lastElementChild.setAttribute("onclick", "itemStyleChange(1)");
		
		
		const child = createDiv('', 'btn tripple off', 'itemStyleChange(-1)', 'Previous Step');
		parent.insertBefore(child, parent.lastElementChild);
		document.getElementById("next")[0].setAttribute("onClick", "nextJoinStep(2)");
		document.getElementById("next")[0].innertext = "가입신청";
	//	document.getElementsByName("previous")[0].setAttribute("innertext", "가입신청");
		document.getElementById("previous")[0].setAttribute("innertext", "NEXT");
	}
	else if(currentIdx == 0){
		const parent = document.getElementById("footer");
		parent.firstElementChild.className = "btn double off";
		parent.lastElementChild.className = "btn double on";
		
		parent.removeChild(parent.lastElementChild.previousElementSibling);
	}
	itemIdx += idx;
}

/* Authentication 이전 Get 방식의 페이지 요청 */
function movePage(target){
	const form = createForm("", target, "get");
	document.body.appendChild(form);
	form.submit();	
}	

function access(){
	const form = createForm("", "Access", "post");
	const inputZone = document.getElementById("inputZone");
	const communicationBox = document.getElementsByClassName("communicationBox")[0];
	const message = ["매장코드 형식을 확인하세요.", "직원코드 형식을 확인하세요.", "핀번호 형식을 확인하세요"];
	let isSubmit;
		
	for(let idx=0; idx<inputZone.children.length; idx++){
		isSubmit = lengthCheck(inputZone.children[idx])
		if(!isSubmit)	{
			inputZone.children[idx].value = "";
			inputZone.children[idx].setAttribute("placeholder", message[idx]);
			inputZone.children[idx].focus();
			break;
		}
	}
	
	const hidden = createInputBox("hidden", "accessPublicIp", publicIp, "");
	form.appendChild(inputZone);
	form.appendChild(hidden);
	communicationBox.appendChild(form);
	form.submit();
}

/* Password Validation */
function isCharCheck(text, type){
	let result;
	
	const largeChar = /[A-Z]/;
	const smallChar = /[a-z]/;
	const num = /[0-9]/;
	const specialChar = /[!@#$%^&*]/;
	
	let typeCount = 0;
	
	if(largeChar.test(text)) typeCount++;
	if(smallChar.test(text)) typeCount++;
	if(num.test(text)) typeCount++;
	if(specialChar.test(text)) typeCount++;
	
	if(type){
		result = typeCount >= 3? true:false;
	}else{
		result = typeCount == 0? true:false;
	}
	
	return result;
}